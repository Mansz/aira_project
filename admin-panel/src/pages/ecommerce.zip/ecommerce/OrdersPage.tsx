import { useState } from 'react';
import {
  Box,
  Paper,
  Typography,
  Grid,
  Card,
  CardContent,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  IconButton,
  TextField,
  InputAdornment,
  Stack,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Stepper,
  Step,
  StepLabel,
  Menu,
  MenuItem,
} from '@mui/material';
import {
  Search,
  Visibility,
  ShoppingCart,
  LocalShipping,
  AttachMoney,
  Timeline,
  FilterList,
  MoreVert,
} from '@mui/icons-material';

// Mock data for orders
const orders = [
  {
    id: 'ORD-001',
    customer: {
      name: 'John Doe',
      email: 'john@example.com',
      phone: '+62812345678',
    },
    items: [
      {
        name: 'Fashion Item 1',
        quantity: 2,
        price: 150000,
      },
      {
        name: 'Fashion Item 2',
        quantity: 1,
        price: 200000,
      },
    ],
    total: 500000,
    status: 'pending',
    paymentStatus: 'unpaid',
    shippingStatus: 'pending',
    orderDate: '2024-01-20T14:30:00',
    address: 'Jl. Example No. 123, Jakarta',
  },
  {
    id: 'ORD-002',
    customer: {
      name: 'Jane Smith',
      email: 'jane@example.com',
      phone: '+62812345679',
    },
    items: [
      {
        name: 'Fashion Item 3',
        quantity: 1,
        price: 300000,
      },
    ],
    total: 300000,
    status: 'processing',
    paymentStatus: 'paid',
    shippingStatus: 'shipped',
    orderDate: '2024-01-20T13:15:00',
    address: 'Jl. Sample No. 456, Surabaya',
  },
];

// Order status steps
const orderSteps = ['Pending', 'Processing', 'Shipped', 'Delivered'];

interface OrderDetailDialogProps {
  open: boolean;
  order?: any;
  onClose: () => void;
}

const OrderDetailDialog = ({ open, order, onClose }: OrderDetailDialogProps) => {
  if (!order) return null;

  const getStepIndex = (status: string) => {
    return orderSteps.findIndex(
      (step) => step.toLowerCase() === status.toLowerCase()
    );
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle>
        Detail Pesanan {order.id}
      </DialogTitle>
      <DialogContent>
        <Grid container spacing={3}>
          <Grid item xs={12}>
            <Stepper activeStep={getStepIndex(order.status)} sx={{ mb: 4 }}>
              {orderSteps.map((label) => (
                <Step key={label}>
                  <StepLabel>{label}</StepLabel>
                </Step>
              ))}
            </Stepper>
          </Grid>

          <Grid item xs={12} md={6}>
            <Card variant="outlined">
              <CardContent>
                <Typography variant="subtitle2" color="text.secondary">
                  Informasi Pelanggan
                </Typography>
                <Box sx={{ mt: 1 }}>
                  <Typography variant="body1">{order.customer.name}</Typography>
                  <Typography variant="body2">{order.customer.email}</Typography>
                  <Typography variant="body2">{order.customer.phone}</Typography>
                </Box>
              </CardContent>
            </Card>
          </Grid>

          <Grid item xs={12} md={6}>
            <Card variant="outlined">
              <CardContent>
                <Typography variant="subtitle2" color="text.secondary">
                  Alamat Pengiriman
                </Typography>
                <Typography variant="body1" sx={{ mt: 1 }}>
                  {order.address}
                </Typography>
              </CardContent>
            </Card>
          </Grid>

          <Grid item xs={12}>
            <TableContainer>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell>Produk</TableCell>
                    <TableCell align="right">Harga</TableCell>
                    <TableCell align="right">Jumlah</TableCell>
                    <TableCell align="right">Subtotal</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {order.items.map((item: any, index: number) => (
                    <TableRow key={index}>
                      <TableCell>{item.name}</TableCell>
                      <TableCell align="right">
                        Rp {item.price.toLocaleString()}
                      </TableCell>
                      <TableCell align="right">{item.quantity}</TableCell>
                      <TableCell align="right">
                        Rp {(item.price * item.quantity).toLocaleString()}
                      </TableCell>
                    </TableRow>
                  ))}
                  <TableRow>
                    <TableCell colSpan={3}>
                      <Typography variant="subtitle2">Total</Typography>
                    </TableCell>
                    <TableCell align="right">
                      <Typography variant="subtitle2">
                        Rp {order.total.toLocaleString()}
                      </Typography>
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </TableContainer>
          </Grid>
        </Grid>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Tutup</Button>
        <Button
          variant="contained"
          sx={{
            backgroundColor: 'black',
            '&:hover': {
              backgroundColor: '#333',
            },
          }}
        >
          Update Status
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export const OrdersPage = () => {
  const [selectedOrder, setSelectedOrder] = useState<any>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterAnchorEl, setFilterAnchorEl] = useState<null | HTMLElement>(null);
  const [selectedStatus, setSelectedStatus] = useState('all');

  // Stats calculation
  const stats = {
    totalOrders: orders.length,
    totalRevenue: orders.reduce((sum, order) => sum + order.total, 0),
    pendingOrders: orders.filter(order => order.status === 'pending').length,
    shippedOrders: orders.filter(order => order.shippingStatus === 'shipped').length,
  };

  const handleFilterClick = (event: React.MouseEvent<HTMLElement>) => {
    setFilterAnchorEl(event.currentTarget);
  };

  const handleFilterClose = () => {
    setFilterAnchorEl(null);
  };

  const handleStatusFilter = (status: string) => {
    setSelectedStatus(status);
    handleFilterClose();
  };

  const getStatusColor = (status: string): "success" | "warning" | "error" | "info" => {
    switch (status) {
      case 'delivered':
        return 'success';
      case 'shipped':
        return 'info';
      case 'processing':
        return 'warning';
      case 'pending':
        return 'error';
      default:
        return 'warning';
    }
  };

  const filteredOrders = orders.filter((order) => {
    const matchesSearch =
      order.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.customer.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus =
      selectedStatus === 'all' || order.status === selectedStatus;
    return matchesSearch && matchesStatus;
  });

  return (
    <Box>
      <Typography variant="h4" sx={{ mb: 4 }}>
        Pesanan
      </Typography>

      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Stack spacing={1}>
                <ShoppingCart sx={{ fontSize: 40, color: 'primary.main' }} />
                <Typography variant="h4">{stats.totalOrders}</Typography>
                <Typography variant="body2" color="text.secondary">
                  Total Pesanan
                </Typography>
              </Stack>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Stack spacing={1}>
                <AttachMoney sx={{ fontSize: 40, color: 'success.main' }} />
                <Typography variant="h4">
                  Rp {stats.totalRevenue.toLocaleString()}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Total Pendapatan
                </Typography>
              </Stack>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Stack spacing={1}>
                <Timeline sx={{ fontSize: 40, color: 'warning.main' }} />
                <Typography variant="h4">{stats.pendingOrders}</Typography>
                <Typography variant="body2" color="text.secondary">
                  Pesanan Pending
                </Typography>
              </Stack>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Stack spacing={1}>
                <LocalShipping sx={{ fontSize: 40, color: 'info.main' }} />
                <Typography variant="h4">{stats.shippedOrders}</Typography>
                <Typography variant="body2" color="text.secondary">
                  Sedang Dikirim
                </Typography>
              </Stack>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      <Paper sx={{ p: 3 }}>
        <Box sx={{ mb: 3, display: 'flex', gap: 2 }}>
          <TextField
            fullWidth
            placeholder="Cari pesanan..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <Search />
                </InputAdornment>
              ),
            }}
          />
          <Button
            startIcon={<FilterList />}
            onClick={handleFilterClick}
            sx={{ color: 'black' }}
          >
            Filter
          </Button>
        </Box>

        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>ID Pesanan</TableCell>
                <TableCell>Pelanggan</TableCell>
                <TableCell>Total</TableCell>
                <TableCell>Status</TableCell>
                <TableCell>Pembayaran</TableCell>
                <TableCell>Pengiriman</TableCell>
                <TableCell>Tanggal</TableCell>
                <TableCell align="right">Aksi</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {filteredOrders.map((order) => (
                <TableRow key={order.id}>
                  <TableCell>{order.id}</TableCell>
                  <TableCell>
                    <Stack>
                      <Typography variant="body2">{order.customer.name}</Typography>
                      <Typography variant="caption" color="text.secondary">
                        {order.customer.email}
                      </Typography>
                    </Stack>
                  </TableCell>
                  <TableCell>Rp {order.total.toLocaleString()}</TableCell>
                  <TableCell>
                    <Chip
                      size="small"
                      label={order.status}
                      color={getStatusColor(order.status)}
                    />
                  </TableCell>
                  <TableCell>
                    <Chip
                      size="small"
                      label={order.paymentStatus}
                      color={order.paymentStatus === 'paid' ? 'success' : 'error'}
                    />
                  </TableCell>
                  <TableCell>
                    <Chip
                      size="small"
                      label={order.shippingStatus}
                      color={getStatusColor(order.shippingStatus)}
                    />
                  </TableCell>
                  <TableCell>
                    {new Date(order.orderDate).toLocaleDateString('id-ID')}
                  </TableCell>
                  <TableCell align="right">
                    <IconButton
                      size="small"
                      onClick={() => setSelectedOrder(order)}
                      sx={{ color: 'black' }}
                    >
                      <Visibility />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      <Menu
        anchorEl={filterAnchorEl}
        open={Boolean(filterAnchorEl)}
        onClose={handleFilterClose}
      >
        <MenuItem onClick={() => handleStatusFilter('all')}>
          Semua Status
        </MenuItem>
        <MenuItem onClick={() => handleStatusFilter('pending')}>
          Pending
        </MenuItem>
        <MenuItem onClick={() => handleStatusFilter('processing')}>
          Processing
        </MenuItem>
        <MenuItem onClick={() => handleStatusFilter('shipped')}>
          Shipped
        </MenuItem>
        <MenuItem onClick={() => handleStatusFilter('delivered')}>
          Delivered
        </MenuItem>
      </Menu>

      <OrderDetailDialog
        open={Boolean(selectedOrder)}
        order={selectedOrder}
        onClose={() => setSelectedOrder(null)}
      />
    </Box>
  );
};
