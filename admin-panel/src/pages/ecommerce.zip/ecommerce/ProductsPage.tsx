import { useState } from 'react';
import {
  Box,
  Paper,
  Typography,
  Grid,
  Card,
  CardContent,
  CardMedia,
  Button,
  IconButton,
  TextField,
  InputAdornment,
  Stack,
  Chip,
  Menu,
  MenuItem,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  FormControl,
  InputLabel,
  Select,
} from '@mui/material';
import {
  Add,
  Search,
  Edit,
  Delete,
  FilterList,
  CloudUpload,
  MoreVert,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';

// Mock data for products
const products = [
  {
    id: 1,
    name: 'Fashion Item 1',
    category: 'Clothing',
    price: 150000,
    stock: 50,
    image: 'https://via.placeholder.com/200',
    status: 'active',
  },
  {
    id: 2,
    name: 'Fashion Item 2',
    category: 'Accessories',
    price: 200000,
    stock: 30,
    image: 'https://via.placeholder.com/200',
    status: 'active',
  },
];

interface FilterMenuProps {
  anchorEl: null | HTMLElement;
  onClose: () => void;
  onFilter: (category: string) => void;
}

const FilterMenu = ({ anchorEl, onClose, onFilter }: FilterMenuProps) => (
  <Menu
    anchorEl={anchorEl}
    open={Boolean(anchorEl)}
    onClose={onClose}
    anchorOrigin={{
      vertical: 'bottom',
      horizontal: 'right',
    }}
    transformOrigin={{
      vertical: 'top',
      horizontal: 'right',
    }}
  >
    <MenuItem onClick={() => { onFilter('all'); onClose(); }}>
      Semua Kategori
    </MenuItem>
    <MenuItem onClick={() => { onFilter('Clothing'); onClose(); }}>
      Clothing
    </MenuItem>
    <MenuItem onClick={() => { onFilter('Accessories'); onClose(); }}>
      Accessories
    </MenuItem>
  </Menu>
);

interface DeleteConfirmDialogProps {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
}

const DeleteConfirmDialog = ({ open, onClose, onConfirm }: DeleteConfirmDialogProps) => (
  <Dialog open={open} onClose={onClose}>
    <DialogTitle>Konfirmasi Hapus</DialogTitle>
    <DialogContent>
      Apakah Anda yakin ingin menghapus produk ini? Tindakan ini tidak dapat dibatalkan.
    </DialogContent>
    <DialogActions>
      <Button onClick={onClose}>Batal</Button>
      <Button
        onClick={onConfirm}
        color="error"
        variant="contained"
      >
        Hapus
      </Button>
    </DialogActions>
  </Dialog>
);

export const ProductsPage = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [filterAnchorEl, setFilterAnchorEl] = useState<null | HTMLElement>(null);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<any>(null);
  const [menuAnchorEl, setMenuAnchorEl] = useState<{
    [key: number]: HTMLElement | null;
  }>({});

  const handleFilterClick = (event: React.MouseEvent<HTMLElement>) => {
    setFilterAnchorEl(event.currentTarget);
  };

  const handleFilterClose = () => {
    setFilterAnchorEl(null);
  };

  const handleFilter = (category: string) => {
    setSelectedCategory(category);
  };

  const handleMenuOpen = (event: React.MouseEvent<HTMLElement>, productId: number) => {
    setMenuAnchorEl({ ...menuAnchorEl, [productId]: event.currentTarget });
  };

  const handleMenuClose = (productId: number) => {
    setMenuAnchorEl({ ...menuAnchorEl, [productId]: null });
  };

  const handleEdit = (productId: number) => {
    navigate(`/products/${productId}/edit`);
  };

  const handleDelete = (product: any) => {
    setSelectedProduct(product);
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = () => {
    console.log('Deleting product:', selectedProduct?.id);
    // Here you would make an API call to delete the product
    setDeleteDialogOpen(false);
    setSelectedProduct(null);
  };

  const filteredProducts = products.filter((product) => {
    const matchesSearch = product.name
      .toLowerCase()
      .includes(searchQuery.toLowerCase());
    const matchesCategory =
      selectedCategory === 'all' || product.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <Box>
      <Box sx={{ mb: 4, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Typography variant="h4">Produk</Typography>
        <Button
          variant="contained"
          startIcon={<Add />}
          onClick={() => navigate('/products/create')}
          sx={{
            backgroundColor: 'black',
            '&:hover': {
              backgroundColor: '#333',
            },
          }}
        >
          Tambah Produk
        </Button>
      </Box>

      <Paper sx={{ p: 3, mb: 3 }}>
        <Grid container spacing={2} alignItems="center">
          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              placeholder="Cari produk..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <Search />
                  </InputAdornment>
                ),
              }}
            />
          </Grid>
          <Grid item xs={12} md={6}>
            <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
              <Button
                startIcon={<FilterList />}
                onClick={handleFilterClick}
                sx={{ color: 'black' }}
              >
                Filter
              </Button>
            </Box>
          </Grid>
        </Grid>
      </Paper>

      <Grid container spacing={3}>
        {filteredProducts.map((product) => (
          <Grid item xs={12} sm={6} md={4} lg={3} key={product.id}>
            <Card>
              <CardMedia
                component="img"
                height="200"
                image={product.image}
                alt={product.name}
              />
              <CardContent>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <Box>
                    <Typography variant="h6" noWrap>
                      {product.name}
                    </Typography>
                    <Typography variant="body2" color="text.secondary" gutterBottom>
                      {product.category}
                    </Typography>
                    <Typography variant="subtitle1" sx={{ fontWeight: 'bold' }}>
                      Rp {product.price.toLocaleString()}
                    </Typography>
                    <Stack direction="row" spacing={1} sx={{ mt: 1 }}>
                      <Chip
                        size="small"
                        label={`Stok: ${product.stock}`}
                        color={product.stock > 0 ? 'success' : 'error'}
                      />
                      <Chip
                        size="small"
                        label={product.status}
                        color={product.status === 'active' ? 'primary' : 'default'}
                      />
                    </Stack>
                  </Box>
                  <IconButton
                    size="small"
                    onClick={(e) => handleMenuOpen(e, product.id)}
                  >
                    <MoreVert />
                  </IconButton>
                </Box>
              </CardContent>
              <Menu
                anchorEl={menuAnchorEl[product.id]}
                open={Boolean(menuAnchorEl[product.id])}
                onClose={() => handleMenuClose(product.id)}
              >
                <MenuItem onClick={() => {
                  handleEdit(product.id);
                  handleMenuClose(product.id);
                }}>
                  <Edit sx={{ mr: 1 }} /> Edit
                </MenuItem>
                <MenuItem
                  onClick={() => {
                    handleDelete(product);
                    handleMenuClose(product.id);
                  }}
                  sx={{ color: 'error.main' }}
                >
                  <Delete sx={{ mr: 1 }} /> Hapus
                </MenuItem>
              </Menu>
            </Card>
          </Grid>
        ))}
      </Grid>

      <FilterMenu
        anchorEl={filterAnchorEl}
        onClose={handleFilterClose}
        onFilter={handleFilter}
      />

      <DeleteConfirmDialog
        open={deleteDialogOpen}
        onClose={() => setDeleteDialogOpen(false)}
        onConfirm={handleDeleteConfirm}
      />
    </Box>
  );
};
