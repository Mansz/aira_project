import { useState } from 'react';
import {
  Box,
  Paper,
  Typography,
  Grid,
  Card,
  CardContent,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  IconButton,
  TextField,
  InputAdornment,
  Stack,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Menu,
  MenuItem,
} from '@mui/material';
import {
  Search,
  Visibility,
  AttachMoney,
  AccountBalance,
  Receipt,
  FilterList,
  CreditCard,
} from '@mui/icons-material';

// Mock data for payments
const payments = [
  {
    id: 'PAY-001',
    orderId: 'ORD-001',
    customer: {
      name: 'John Doe',
      email: 'john@example.com',
    },
    amount: 500000,
    method: 'bank_transfer',
    status: 'completed',
    date: '2024-01-20T14:30:00',
    bankAccount: {
      bank: 'BCA',
      number: '********1234',
      holder: 'John Doe',
    },
  },
  {
    id: 'PAY-002',
    orderId: 'ORD-002',
    customer: {
      name: 'Jane Smith',
      email: 'jane@example.com',
    },
    amount: 300000,
    method: 'credit_card',
    status: 'pending',
    date: '2024-01-20T13:15:00',
    cardInfo: {
      type: 'Visa',
      last4: '4321',
    },
  },
];

interface PaymentDetailDialogProps {
  open: boolean;
  payment?: any;
  onClose: () => void;
}

const PaymentDetailDialog = ({ open, payment, onClose }: PaymentDetailDialogProps) => {
  if (!payment) return null;

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle>
        Detail Pembayaran {payment.id}
      </DialogTitle>
      <DialogContent>
        <Grid container spacing={3}>
          <Grid item xs={12}>
            <Card variant="outlined">
              <CardContent>
                <Typography variant="subtitle2" color="text.secondary">
                  Informasi Pembayaran
                </Typography>
                <Box sx={{ mt: 2 }}>
                  <Stack spacing={2}>
                    <Box>
                      <Typography variant="body2" color="text.secondary">
                        ID Pesanan
                      </Typography>
                      <Typography variant="body1">{payment.orderId}</Typography>
                    </Box>
                    <Box>
                      <Typography variant="body2" color="text.secondary">
                        Jumlah
                      </Typography>
                      <Typography variant="body1">
                        Rp {payment.amount.toLocaleString()}
                      </Typography>
                    </Box>
                    <Box>
                      <Typography variant="body2" color="text.secondary">
                        Metode Pembayaran
                      </Typography>
                      <Typography variant="body1" sx={{ textTransform: 'capitalize' }}>
                        {payment.method.replace('_', ' ')}
                      </Typography>
                    </Box>
                    {payment.bankAccount && (
                      <Box>
                        <Typography variant="body2" color="text.secondary">
                          Informasi Bank
                        </Typography>
                        <Typography variant="body1">
                          {payment.bankAccount.bank} - {payment.bankAccount.number}
                        </Typography>
                        <Typography variant="body2">
                          a.n. {payment.bankAccount.holder}
                        </Typography>
                      </Box>
                    )}
                    {payment.cardInfo && (
                      <Box>
                        <Typography variant="body2" color="text.secondary">
                          Informasi Kartu
                        </Typography>
                        <Typography variant="body1">
                          {payment.cardInfo.type} **** {payment.cardInfo.last4}
                        </Typography>
                      </Box>
                    )}
                  </Stack>
                </Box>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12}>
            <Card variant="outlined">
              <CardContent>
                <Typography variant="subtitle2" color="text.secondary">
                  Informasi Pelanggan
                </Typography>
                <Box sx={{ mt: 2 }}>
                  <Typography variant="body1">{payment.customer.name}</Typography>
                  <Typography variant="body2">{payment.customer.email}</Typography>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Tutup</Button>
        {payment.status === 'pending' && (
          <Button
            variant="contained"
            sx={{
              backgroundColor: 'black',
              '&:hover': {
                backgroundColor: '#333',
              },
            }}
          >
            Konfirmasi Pembayaran
          </Button>
        )}
      </DialogActions>
    </Dialog>
  );
};

export const PaymentsPage = () => {
  const [selectedPayment, setSelectedPayment] = useState<any>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterAnchorEl, setFilterAnchorEl] = useState<null | HTMLElement>(null);
  const [selectedStatus, setSelectedStatus] = useState('all');

  // Stats calculation
  const stats = {
    totalPayments: payments.length,
    totalAmount: payments.reduce((sum, payment) => sum + payment.amount, 0),
    completedPayments: payments.filter(payment => payment.status === 'completed').length,
    pendingPayments: payments.filter(payment => payment.status === 'pending').length,
  };

  const handleFilterClick = (event: React.MouseEvent<HTMLElement>) => {
    setFilterAnchorEl(event.currentTarget);
  };

  const handleFilterClose = () => {
    setFilterAnchorEl(null);
  };

  const handleStatusFilter = (status: string) => {
    setSelectedStatus(status);
    handleFilterClose();
  };

  const getStatusColor = (status: string): "success" | "warning" | "error" => {
    switch (status) {
      case 'completed':
        return 'success';
      case 'pending':
        return 'warning';
      default:
        return 'error';
    }
  };

  const getPaymentMethodIcon = (method: string) => {
    switch (method) {
      case 'credit_card':
        return <CreditCard sx={{ fontSize: 20 }} />;
      case 'bank_transfer':
        return <AccountBalance sx={{ fontSize: 20 }} />;
      default:
        return <AttachMoney sx={{ fontSize: 20 }} />;
    }
  };

  const filteredPayments = payments.filter((payment) => {
    const matchesSearch =
      payment.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      payment.customer.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus =
      selectedStatus === 'all' || payment.status === selectedStatus;
    return matchesSearch && matchesStatus;
  });

  return (
    <Box>
      <Typography variant="h4" sx={{ mb: 4 }}>
        Pembayaran
      </Typography>

      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Stack spacing={1}>
                <Receipt sx={{ fontSize: 40, color: 'primary.main' }} />
                <Typography variant="h4">{stats.totalPayments}</Typography>
                <Typography variant="body2" color="text.secondary">
                  Total Transaksi
                </Typography>
              </Stack>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Stack spacing={1}>
                <AttachMoney sx={{ fontSize: 40, color: 'success.main' }} />
                <Typography variant="h4">
                  Rp {stats.totalAmount.toLocaleString()}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Total Pembayaran
                </Typography>
              </Stack>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Stack spacing={1}>
                <AccountBalance sx={{ fontSize: 40, color: 'info.main' }} />
                <Typography variant="h4">{stats.completedPayments}</Typography>
                <Typography variant="body2" color="text.secondary">
                  Pembayaran Selesai
                </Typography>
              </Stack>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Stack spacing={1}>
                <CreditCard sx={{ fontSize: 40, color: 'warning.main' }} />
                <Typography variant="h4">{stats.pendingPayments}</Typography>
                <Typography variant="body2" color="text.secondary">
                  Menunggu Konfirmasi
                </Typography>
              </Stack>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      <Paper sx={{ p: 3 }}>
        <Box sx={{ mb: 3, display: 'flex', gap: 2 }}>
          <TextField
            fullWidth
            placeholder="Cari pembayaran..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <Search />
                </InputAdornment>
              ),
            }}
          />
          <Button
            startIcon={<FilterList />}
            onClick={handleFilterClick}
            sx={{ color: 'black' }}
          >
            Filter
          </Button>
        </Box>

        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>ID Pembayaran</TableCell>
                <TableCell>ID Pesanan</TableCell>
                <TableCell>Pelanggan</TableCell>
                <TableCell>Metode</TableCell>
                <TableCell>Jumlah</TableCell>
                <TableCell>Status</TableCell>
                <TableCell>Tanggal</TableCell>
                <TableCell align="right">Aksi</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {filteredPayments.map((payment) => (
                <TableRow key={payment.id}>
                  <TableCell>{payment.id}</TableCell>
                  <TableCell>{payment.orderId}</TableCell>
                  <TableCell>
                    <Stack>
                      <Typography variant="body2">{payment.customer.name}</Typography>
                      <Typography variant="caption" color="text.secondary">
                        {payment.customer.email}
                      </Typography>
                    </Stack>
                  </TableCell>
                  <TableCell>
                    <Stack direction="row" spacing={1} alignItems="center">
                      {getPaymentMethodIcon(payment.method)}
                      <Typography variant="body2" sx={{ textTransform: 'capitalize' }}>
                        {payment.method.replace('_', ' ')}
                      </Typography>
                    </Stack>
                  </TableCell>
                  <TableCell>Rp {payment.amount.toLocaleString()}</TableCell>
                  <TableCell>
                    <Chip
                      size="small"
                      label={payment.status}
                      color={getStatusColor(payment.status)}
                    />
                  </TableCell>
                  <TableCell>
                    {new Date(payment.date).toLocaleDateString('id-ID')}
                  </TableCell>
                  <TableCell align="right">
                    <IconButton
                      size="small"
                      onClick={() => setSelectedPayment(payment)}
                      sx={{ color: 'black' }}
                    >
                      <Visibility />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      <Menu
        anchorEl={filterAnchorEl}
        open={Boolean(filterAnchorEl)}
        onClose={handleFilterClose}
      >
        <MenuItem onClick={() => handleStatusFilter('all')}>
          Semua Status
        </MenuItem>
        <MenuItem onClick={() => handleStatusFilter('completed')}>
          Completed
        </MenuItem>
        <MenuItem onClick={() => handleStatusFilter('pending')}>
          Pending
        </MenuItem>
        <MenuItem onClick={() => handleStatusFilter('failed')}>
          Failed
        </MenuItem>
      </Menu>

      <PaymentDetailDialog
        open={Boolean(selectedPayment)}
        payment={selectedPayment}
        onClose={() => setSelectedPayment(null)}
      />
    </Box>
  );
};
